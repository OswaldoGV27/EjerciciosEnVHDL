module cod_prio3a8 ( 
	entrada,
	enable,
	salida,
	y
	) ;

input [7:0] entrada;
input  enable;
inout [2:0] salida;
inout  y;
